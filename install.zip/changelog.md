### v1.0.0 - 24 Oct 2024
* Initial release